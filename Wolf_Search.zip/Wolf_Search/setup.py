from cx_Freeze import setup,Executable
setup(name='Wolfram Query',
       version='1.0',
       description='Wolfram Query __*made by AnonWiz',
       executables= [Executable("wolf.py")])
         
